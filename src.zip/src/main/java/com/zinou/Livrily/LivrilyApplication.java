package com.zinou.Livrily;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivrilyApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivrilyApplication.class, args);
	}

}
