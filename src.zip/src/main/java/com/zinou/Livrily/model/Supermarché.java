package com.zinou.Livrily.model;

public class Supermarché {

	private int Supermarché_ID;
	private int Filiale_ID;
	private String NomSupermarché;
	private int TéléphoneSupermarché;
	private String EmailSupermarché;
	public int getSupermarché_ID() {
		return Supermarché_ID;


	}
	public void setSupermarché_ID(int supermarché_ID) {
		Supermarché_ID = supermarché_ID;
	}
	public int getFiliale_ID() {
		return Filiale_ID;
	}
	public void setFiliale_ID(int filiale_ID) {
		Filiale_ID = filiale_ID;
	}
	public String getNomSupermarché() {
		return NomSupermarché;
	}
	public void setNomSupermarché(String nomSupermarché) {
		NomSupermarché = nomSupermarché;
	}
	public int getTéléphoneSupermarché() {
		return TéléphoneSupermarché;
	}
	public void setTéléphoneSupermarché(int téléphoneSupermarché) {
		TéléphoneSupermarché = téléphoneSupermarché;
	}
	public String getEmailSupermarché() {
		return EmailSupermarché;
	}
	public void setEmailSupermarché(String emailSupermarché) {
		EmailSupermarché = emailSupermarché;
	}














}
