package com.zinou.Livrily.model;

public class Admine_de_Filiale {
	
	private int Admine_de_Filiale_ID;
	private int Utilisateur_ID;
	
	
	public int getAdmine_de_Filiale_ID() {
		return Admine_de_Filiale_ID;
	}
	public void setAdmine_de_Filiale_ID(int admine_de_Filiale_ID) {
		Admine_de_Filiale_ID = admine_de_Filiale_ID;
	}
	public int getUtilisateur_ID() {
		return Utilisateur_ID;
	}
	public void setUtilisateur_ID(int utilisateur_ID) {
		Utilisateur_ID = utilisateur_ID;
	}
	
	
	



}
