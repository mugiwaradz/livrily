package com.zinou.Livrily.model;

public class AdressUtilisateur {

	private int AdressUtilisateur_ID;
	private int Utilisateur_ID;
	private int Adress_ID;


	public int getAdressUtilisateur_ID() {
		return AdressUtilisateur_ID;
	}
	public void setAdressUtilisateur_ID(int adressUtilisateur_ID) {
		AdressUtilisateur_ID = adressUtilisateur_ID;
	}
	public int getUtilisateur_ID() {
		return Utilisateur_ID;
	}
	public void setUtilisateur_ID(int utilisateur_ID) {
		Utilisateur_ID = utilisateur_ID;
	}
	public int getAdress_ID() {
		return Adress_ID;
	}
	public void setAdress_ID(int adress_ID) {
		Adress_ID = adress_ID;
	}




}
