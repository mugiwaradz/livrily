package com.zinou.Livrily.model;

public class Admine_de_SuperMarché {

	private int Admine_de_SuperMarché_ID;
	private int Utilisateur_ID;
	
	
	
	public int getAdmine_de_SuperMarché_ID() {
		return Admine_de_SuperMarché_ID;
	}
	public void setAdmine_de_SuperMarché_ID(int admine_de_SuperMarché) {
		Admine_de_SuperMarché_ID = admine_de_SuperMarché;
	}
	public int getUtilisateur_ID() {
		return Utilisateur_ID;
	}
	public void setUtilisateur_ID(int utilisateur_ID) {
		Utilisateur_ID = utilisateur_ID;
	}

	
	
}
