package com.zinou.Livrily.model;

public class CtegoréProduit {
	
	private int CtegoréProduit_ID;
	private String NomCatégoré;
	private String ImageCatégoré;


	public int getCtegoréProduit_ID() {
		return CtegoréProduit_ID;
	}
	public void setCtegoréProduit_ID(int ctegoréProduit_ID) {
		CtegoréProduit_ID = ctegoréProduit_ID;
	}
	public String getNomCatégoré() {
		return NomCatégoré;
	}
	public void setNomCatégoré(String nomCatégoré) {
		NomCatégoré = nomCatégoré;
	}
	public String getImageCatégoré() {
		return ImageCatégoré;
	}
	public void setImageCatégoré(String imageCatégoré) {
		ImageCatégoré = imageCatégoré;
	}




}
