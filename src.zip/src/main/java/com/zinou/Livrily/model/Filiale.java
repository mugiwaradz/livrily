package com.zinou.Livrily.model;

public class Filiale {

	private int Filiale_ID;
	private String NomDeFiliale;
	private String EmailDeFiliale;
	private String SiteWebDeFiliale;


	public int getFiliale_ID() {
		return Filiale_ID;
	}
	public void setFiliale_ID(int filiale_ID) {
		Filiale_ID = filiale_ID;
	}
	public String getNomDeFiliale() {
		return NomDeFiliale;
	}
	public void setNomDeFiliale(String nomDeFiliale) {
		NomDeFiliale = nomDeFiliale;
	}
	public String getEmailDeFiliale() {
		return EmailDeFiliale;
	}
	public void setEmailDeFiliale(String emailDeFiliale) {
		EmailDeFiliale = emailDeFiliale;
	}
	public String getSiteWebDeFiliale() {
		return SiteWebDeFiliale;
	}
	public void setSiteWebDeFiliale(String siteWebDeFiliale) {
		SiteWebDeFiliale = siteWebDeFiliale;
	}



}
