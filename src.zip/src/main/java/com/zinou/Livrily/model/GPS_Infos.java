package com.zinou.Livrily.model;

public class GPS_Infos {

	
	private int GPS_Infos_ID;
	private int latitude;
	private int longitude;
	public int getGPS_Infos_ID() {
		return GPS_Infos_ID;
	}
	public void setGPS_Infos_ID(int gPS_Infos_ID) {
		GPS_Infos_ID = gPS_Infos_ID;
	}
	public int getLatitude() {
		return latitude;
	}
	public void setLatitude(int latitude) {
		this.latitude = latitude;
	}
	public int getLongitude() {
		return longitude;
	}
	public void setLongitude(int longitude) {
		this.longitude = longitude;
	}
	
	
	
	

}
