package util;

public class Commander {
//
//	public Commandecomplette Getcommande(ResultSet rs) {
//		try {
//			
////			return commandecomplette;
//
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return null;
//
//	
//	
//
//}
}
